package com.example.rr.ui.slideshow;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class SlideshowViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public SlideshowViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Welcome to the jobs and wealth page. Tired of looking for jobs without getting one? Or " +
                "poverty is biting you down ,attacking like an armed robber,then this is the right place for you." +
                "We make sure that you get a nice job within a short time.for the case of money we open your ways to a " +
                "world of riches and prosperity.click the next button to pay and acess a direct communication with our astrologers(waganga)");
    }

    public LiveData<String> getText() {
        return mText;
    }
}