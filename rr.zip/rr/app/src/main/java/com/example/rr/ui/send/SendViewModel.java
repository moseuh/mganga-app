package com.example.rr.ui.send;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class SendViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public SendViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("our astrologers make it easy to recover lost items .from all range of products such as electronics" +
                ", cars,title deeds and lost children we assure you quality sevices within on week.");
    }

    public LiveData<String> getText() {
        return mText;
    }
}