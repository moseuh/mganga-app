package com.example.rr.ui.tools;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class ToolsViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public ToolsViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("welcome to the funga boma page." +
                "we offer home and property protection services using " +
                "astrological methods." +
                "we make sure your property cannot be stolen by thugs " +
                "we also ensure you trace those who acquire your propert using unjust means." +
                " we have a team of well known and competent astrologists who make sure that there is a value  for money.press the next button to pay for the service and talk to our astrologoists(mganga).");
    }

    public LiveData<String> getText() {
        return mText;
    }
}