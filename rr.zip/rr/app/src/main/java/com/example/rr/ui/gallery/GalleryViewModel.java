package com.example.rr.ui.gallery;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class GalleryViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public GalleryViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("welcome to the world of love.Need the best love potions or revenge for some one who messsed up" +
                "your innocent heart.Then you are in the right place click the next button to pay and have a direct communication" +
                " with our astrologers");
    }

    public LiveData<String> getText() {
        return mText;
    }
}